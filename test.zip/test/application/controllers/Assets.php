<?php 

class Assets extends CI_Controller{

    public function __construct(){

        parent::__construct();
        $this->load->helpers('form');
        $this->load->model('assets_model', 'assets');
    }

    public function addAsset(){
        
        //id	type	row	hostname	serial	motherboard	processor	RAM	HDD	VDCard	space	remarks	date_added	application_id
        $data = array(
            "type"      => $this->input->post('type'),
            "row"       => $this->input->post('row'),
            "hostname"  => $this->input->post('hostname'),
            "serial"    => $this->input->post('serial'),
            "motherboard"=>$this->input->post('motherboard'),
            "processor" => $this->input->post('processor'),
            "RAM"       => $this->input->post('ram'),
            "HDD"       => $this->input->post('hdd'),
            "VDCard"    => $this->input->post('vdcard'),
            "space"     => $this->input->post('space'),
            "remarks"   => $this->input->post('remarks')
        );

        $this->assets->save($data);

		echo json_encode(array("status" => TRUE));
    }

    public function test(){

        $data['new'] = $this->assets->get();
        echo "<pre>";
        print_r($data);
    }

    public function viewComputer(){

        $data = array();
        $get = $this->assets->get()->result();
        foreach ($get as $list) {
            $row = array();
            
            $row[] = '';
            $row[] = $list->id;
            $row[] = $list->type;
            $row[] = $list->row;
            $row[] = $list->hostname;
            $row[] = $list->serial;
            $row[] = $list->motherboard;
            $row[] = $list->processor;
            $row[] = $list->RAM;
            $row[] = $list->HDD;
            $row[] = $list->VDCard;
            $row[] = $list->space;
            $row[] = $list->remarks;
            $row[] = $list->date_added;
            $row[] = '<button class="btn btn-round btn-info btn-xs"><span class="fa fa-pencil"></span></button>
            <button class="btn btn-round btn-danger btn-xs"><span class="fa fa-trash"></span></button>';
        
            $data[] = $row;
        }
        // $output = array(
        //                 "data" => $data,
        //         );
        //output to json format
        return $this->output->set_content_type('application/json')->set_output(json_encode(array('data' => $data)));
        //echo json_encode($data);
    }
    
}