<?php 

class Navigation extends CI_Controller{

    public function __construct(){

        parent::__construct();
    }

    public function index(){
        
        $this->navigate('Dashboard', 'dashboard', 'Summary','active');
    }

    public function computers(){
        
        $this->navigate('Computers', 'computer-tab', 'Computers');
    }

    public function peripherals(){
        
        $this->navigate('Peripherals', 'dashboard', 'Peripherals');
    }

    public function logs(){
        
        $this->navigate('Logs', 'dashboard', 'Logs');
    }

    public function reports(){
        
        $this->navigate('Reports', 'reports','Reports');
    }

    public function archives(){
        
        $this->navigate('Archives', 'dashboard', 'Archives');
    }


    public function authenticate(){

        $this->load->view('index');
    }

    public function first_log(){
        $this->load->view('pages/first_log')
;
    }

    
    public function navigate($title, $page = NULL, $pageBanner = "", $bug = ""){
        $data['title'] = $title;
        $data['page'] = $pageBanner;
        // fix later,,,,,,,,,,,,,,,,,,,,,,
        $data['class'] = $bug;
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topnav');
        if($page != NULL){
            $this->load->view('pages/' .$page, $data);
        }
        $this->load->view('templates/footer');
    }
}

?>