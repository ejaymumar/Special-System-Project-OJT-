<?php 

class Assets_model extends CI_Model{

    private $_table = 'computer';

    public function __construct(){
        parent::__construct();
        $this->load->database();
    }

    public function save($data){
        $this->db->insert($this->_table, $data);
        return $this->db->insert_id();
    }

    public function get($where = NULL){
        if(!is_null($where)){
            $this->db->where($where);
        }else{
            return  $this->db->get($this->_table);    
        }
        return  $this->db->get($this->_table);
    }
}