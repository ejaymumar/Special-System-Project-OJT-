<?php 

class Assets_model extends CI_Model{

    private $_table = 'computer';

    public function __construct(){
        parent::__construct();
        $this->load->database();
    }

    public function save($data){
        $this->db->insert($this->_table, $data);
        return $this->db->insert_id();
    }

    public function get($id = NULL){
        if(is_numeric($id)){
            $this->db->where('id', $id);
        }else{
            return $this->db->get($this->_table);    
        }
        return  $this->db->get($this->_table);
    }

    public function delete($id){
        $this->db->where('id',$id);
        $this->db->delete($this->_table);
    }

    public function update($id, $data){
        $this->db->set($data);
        $this->db->where('id', $id);
        $this->db->update($this->_table);
    }

    // public function try(){
    //     return $this->db->query("SELECT COUNT(computer.type) AS total,computer.type FROM computer GROUP BY computer.type
    //     UNION
    //     SELECT COUNT(peripheral.asset_name),peripheral.asset_name FROM peripheral GROUP BY peripheral.asset_name");
    //     // SELECT COUNT(computer.type),computer.type FROM computer GROUP BY computer.type
    //     // UNION
    //     // SELECT COUNT(peripheral.asset_name),peripheral.asset_name FROM peripheral GROUP BY peripheral.asset_name
    // }

}