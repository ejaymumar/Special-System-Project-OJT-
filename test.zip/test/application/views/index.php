
<!DOCTYPE html>
<html lang="en">
  <head>

    <title>Inventory System | </title>

    <!-- Bootstrap -->
    <link href="<?=base_url('assets/vendors/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?=base_url('assets/vendors/font-awesome/font-awesome.min.css')?>" rel="stylesheet">
    <!-- Animate.css -->
    <link href="<?=base_url('assets/build/css/animate.min.css')?>" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?=base_url('assets/build/css/custom.min.css')?>" rel="stylesheet">


    <link rel="shortcut icon" href="<?=base_url('assets/build/images/logo.png')?>" type="image/gif"/>

    <script>
        var base_url = function(loc = ""){
                var url = "<?php echo site_url('" + loc + "'); ?>";
                return url;
            }
    </script>
    <style type="text/css">
        .has-error{
            border-color: #f26f6f !important;
        }



    </style>
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form id="frmLogin" autocomplete="off">
              <h1>Login Form</h1>
              <div>
                <span class="text-danger"></span>
                <input type="text" name="username" class="form-control" placeholder="Username"/>
              </div>
              <div>
                <span class="text-danger"></span>
                <input type="password" name="password" class="form-control" placeholder="Password"/>
              </div>
              <div>
                <button class="btn btn-default" type="submit">Login</button>
                <a class="reset_pass" href="#">Lost your password?</a>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">New to site?
                  <a href="#signup" class="to_register"> Create Account </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                  <h1><i class="fa fa-hand-pointer-o"></i> ClickableBrand, Inc.</h1>
                  <p>©2016 All Rights Reserved. Gentelella Alela! is a Bootstrap 3 template. Privacy and Terms</p>
                </div>
              </div>
            </form>
          </section>
        </div>

        <div id="register" class="animate form registration_form">
          <section class="login_content">
            <form id="frmRegister" autocomplete="off">
              <h1>Create Account</h1>
              <div>
                <span class="text-danger"></span>
                <input type="text" class="form-control" name="username-register" placeholder="Username" />
              </div>
              <div>
                <span class="text-danger"></span>
                <input type="password" class="form-control" name="password-register" placeholder="Password"/>
              </div>
              <div>
                <span class="text-danger"></span>
                <input type="password" class="form-control" name="confirm-password" placeholder="Confirm Password"/>
              </div>
              <div>
                <button class="btn btn-default" type="submit">Submit</button>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">Already a member ?
                  <a href="#signin" class="to_register"> Log in </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                  <h1><i class="fa fa-hand-pointer-o"></i> ClickableBrand, Inc.</h1>
                  <p>©2016 All Rights Reserved. Gentelella Alela! is a Bootstrap 3 template. Privacy and Terms</p>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?=base_url('assets/jquery.js')?>"></script>
    <!-- Bootstrap -->
    <script src="<?=base_url('assets/vendors/bootstrap/js/bootstrap.min.js')?>"></script>

    <script src="<?=base_url('assets/build/js/user.js')?>"></script>
  </body>
</html>
