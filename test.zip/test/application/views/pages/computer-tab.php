       <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3><?=$page?> Page</h3>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Plain Page</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <button id="btnComp" class="btn btn-success">Add new Data </button>
                      <!-- Modal -->
                      <div id="modalComputer" class="modal fade">
                        <div class="modal-dialog modal-lg">

                          <!-- Modal content-->
                          <div class="modal-content">
                            <div class="modal-header">
                            <h3 class="modal-title text-center">.modal-title</h3>
                            </div>
                            <div class="modal-body">
                              <form id="frmComputer" class="form-horizontal form-label-left">
                                <div class="row">
                                    <div class="form-group">
                                      <label class="control-label col-md-1">Row</label>
                                      <div class="col-md-2">
                                        <input name="row" type="text" class="form-control">
                                      </div>
                                      <label class="control-label col-md-1">Hostname</label>
                                      <div class="col-md-3">
                                        <input name="hostname" type="text" class="form-control">
                                      </div>
                                      <label class="control-label col-md-1">Serial</label>
                                      <div class="col-md-4">
                                        <input name="serial" type="text" class="form-control">
                                      </div>
                                    </div>
                                </div>
                                  
                                  
                              </div>
                              <div class="modal-footer">
                                <button type="submit" class="btn btn-success">Submit</button>
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                              </form>
                              </div>
                            </div>
                          </div>

                      </div>
                      <!-- End Modal content -->
                      <table id="tbl_computers" class="table table-striped bulk_action">
                        <thead style="background-color:#3f5367">
                          <tr class="headings">
                            <th></th>
                            <th>Row </th>
                            <th>Hostname </th>
                            <th>Motherboard </th>
                            <th>Department </th>
                            <th>Operating System </th>
                            <th><span class="nobr">Action</span></th>
                          </tr>
                        </thead>

                        <tbody>
                          <tr>
                            <td></td>
                            <td>02</td>
                            <td>R2S11</td>
                            <td>AsusTek</td>
                            <td>ITD</td>
                            <td>Windows</td>
                            <td>
                              <button class="btn btn-round btn-info btn-xs"><span class="fa fa-pencil"></span></button>
                              <button class="btn btn-round btn-danger btn-xs"><span class="fa fa-trash"></span></button>
                            </td>
                          </tr>
                          <tr>
                            <td></td>
                            <td>09</td>
                            <td>R3S10</td>
                            <td>AsusTek</td>
                            <td>Billing</td>
                            <td>Unix</td>
                            <td><button class="btn btn-round btn-info btn-xs"><span class="fa fa-pencil"></span></button></td>
                          </tr>
                        </tbody>
                      </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- /page content -->

