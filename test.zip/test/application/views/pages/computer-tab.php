       <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3><?=$page?> Page</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Plain Page</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <button class="btn btn-success">Add new Data </button>
                      <table id="tbl_computers" class="table table-striped bulk_action">
                        <thead style="background-color:#3f5367">
                          <tr class="headings">
                            <th></th>
                            <th>Row </th>
                            <th>Hostname </th>
                            <th>Motherboard </th>
                            <th>Department </th>
                            <th>Operating System </th>
                            <th><span class="nobr">Action</span></th>
                          </tr>
                        </thead>

                        <tbody>
                          <tr>
                            <td></td>
                            <td>02</td>
                            <td>R2S11</td>
                            <td>AsusTek</td>
                            <td>ITD</td>
                            <td>$7.45</td>
                            <td><button class="btn btn-round btn-info"><span class="fa fa-pencil"></span></button></td>
                          </tr>
                          <tr>
                            <td></td>
                            <td>09</td>
                            <td>R3S10</td>
                            <td>AsusTek</td>
                            <td>Billing</td>
                            <td>$71.20</td>
                            <td><a href="#">View</a>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

