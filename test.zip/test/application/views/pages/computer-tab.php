  <!-- page content -->
  <div class="right_col" role="main">
    <div class="">
      <div class="page-title">
        <div class="title_left">
          <h3><?=$page?> Page</h3>
        </div>
      </div>

      <div class="clearfix"></div>

      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
            <button id="btnComp" class="btn btn-success">Add Asset</button>
              <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <!-- Modal -->
                <div id="modalComputer" class="modal fade">
                  <div class="modal-dialog modal-lg">

                    <!-- Modal content-->
                    <div class="modal-content">
                      <div class="modal-header">
                      <h3 class="modal-title text-center">.modal-title</h3>
                      </div>
                      <div class="modal-body">
                        <form id="frmComputer" class="form-horizontal form-label-left">
                        <input type="text" name="id" hidden>
                        <label class="control-label">Asset Location:</label>
                          <div class="row">
                          
                            <div class="form-group group-line">
                              <label class="control-label col-md-1">Row</label>
                                <div class="col-md-2">
                                  <select name="row" class="form-control">
                                    <option hidden value="0">-Row-</option>
                                    <?php 
                                      $num = 1;
                                      while($num <= 15){
                                        echo "<option>". $num++ ."</option>";
                                      }
                                    ?>
                                  </select>
                                </div>
                              <label class="control-label col-md-1">Hostname</label>
                                <div class="col-md-2">
                                  <input class="form-control" type="text" name="hostname" disabled>
                                </div>
                              <label class="control-label col-md-1">Type</label>
                                <div class="col-md-2">
                                  <select name="type" class="form-control">
                                      <option hidden>-Type-</option>
                                      <option>Computer</option>
                                      <option>Laptop</option>
                                  </select>
                                </div>
                              <label class="control-label col-md-1">Serial</label>
                                <div class="col-md-2">
                                  <input class="form-control" type="text" name="serial">
                                </div>
                            </div>
                          </div>

                          <label class="control-label">Asset Details:</label>
                          <div class="group-line">
                            <div class="form-group">
                              <label class="control-label col-md-3">Motherboard</label>
                                <div class="col-md-6">
                                  <input type="text" class="form-control" name="motherboard">
                                </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-2">Processor</label>
                                <div class="col-md-3">
                                  <input type="text" class="form-control" name="processor">
                                </div>
                              <label class="control-label col-md-1">RAM</label>
                                <div class="col-md-2">
                                  <input type="text" class="form-control" name="RAM">
                                </div>
                              <label class="control-label col-md-2">HDD Size</label>
                                <div class="col-md-2">
                                  <input type="text" class="form-control" name="HDD">
                                </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-2">Video Card</label>
                                <div class="col-md-3">
                                  <input type="text" class="form-control" name="VDCard">
                                </div>
                              <label class="control-label col-md-2">Space</label>
                                <div class="col-md-3">
                                  <select name="space" class="form-control">
                                      <option hidden>-Space-</option>
                                      <option>Old Operation</option>
                                      <option>Expansion</option>
                                  </select>
                                </div>
                            </div>
                            <div class="form-group">
                                  <label class="control-label text-center">Add Remarks</label>
                                      <textarea rows="4" class="form-control" name="remarks" style="resize:none"></textarea>
                            </div>
                          </div>

                          <label class="control-label">More:</label>
                          <div class="group-line">
                            <div class="form-group">
                              <label class="control-label col-md-3">Applications: </label>
                                <div class="col-md-6">
                                  <input type="text" class="form-control">
                                </div>
                            </div>
                          </div>

                      </div>
                        <div class="modal-footer">
                          <button id="btnSubmit" type="submit" class="btn btn-success">Submit</button>
                          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </form>
                        </div>
                      </div>
                    </div>

                </div>
                <!-- End Modal content -->
                <!-- id	type	row	hostname	serial	motherboard	processor	RAM	HDD	VDCard	space	remarks	date_added	application_id -->
                <table id="tbl_computers" class="table table-striped bulk_action">
                  <thead style="background-color:#3f5367">
                    <tr class="headings">
                      <th></th>
                      <th>ID</th>
                      <th>Type</th>
                      <th>Row</th>
                      <th>Hostname</th>
                      <th>Serial</th>
                      <th>Motherboard</th>
                      <th>Processor </th>
                      <th>RAM</th>
                      <th>HDD</th>
                      <th>VDCard</th>
                      <th>Space</th>
                      <th>Remarks</th>
                      <th>Date Added</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  </tbody>
                </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!-- /page content -->

