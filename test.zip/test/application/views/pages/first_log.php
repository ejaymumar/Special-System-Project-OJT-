
<!DOCTYPE html>
<html lang="en">
  <head>

    <title>Inventory System | </title>

    <!-- Bootstrap -->
    <link href="<?=base_url('assets/vendors/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?=base_url('assets/vendors/font-awesome/font-awesome.min.css')?>" rel="stylesheet">
    <!-- Animate.css -->
    <link href="<?=base_url('assets/build/css/animate.min.css')?>" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?=base_url('assets/build/css/custom.min.css')?>" rel="stylesheet">


    <link rel="shortcut icon" href="<?=base_url('assets/build/images/logo.png')?>" type="image/gif"/>

    <script>
        var base_url = function(loc = ""){
                var url = "<?php echo site_url('" + loc + "'); ?>";
                return url;
            }
    </script>
    <style type="text/css">
        .has-error{
            border-color: #f26f6f !important;
        }



    </style>
  </head>

  <body class="login">

    <div>
      <div class="login_wrapper" style="margin-top: 0">
        <div class="animate form login_form">
          <section class="login_content">
            <form id="frmFirstlog" autocomplete="off">
            <!-- <form id="frmFirstlog" enctype="multipart/form-data" method="post" accept-charset="utf-8" autocomplete="off"> -->

              <h1>Update Form</h1>
              <div>
                <span class="text-danger"></span>
                <input type="text" value="<?php echo $this->session->userdata('username');?>" class="form-control" disabled />
              </div>
              <div>
                <span class="text-danger"></span>
                <input type="text" name="firstname" class="form-control" value=" " placeholder="Firstname"/>
              </div>
              <div>
                <span class="text-danger"></span>
                <input type="text" name="middlename" class="form-control" value=" " placeholder="Middlename"/>
              </div>
              <div>
                <span class="text-danger"></span>
                <input type="text" name="lastname" class="form-control" value=" " placeholder="Lastname"/>
              </div>
              <div>
                <span class="text-danger"></span>
                <input type="date" name="DOB" class="form-control" placeholder="Date of Birth" /><br>
              </div>
              <div>
                <span class="text-danger"></span>
                <input type="text" name="age" class="form-control" placeholder="Age"/>
              </div>
              <div>
                <span class="text-danger"></span>
                <input type="text" name="contact" class="form-control" placeholder="Contact" maxlength="11" />
              </div>
              <div>
                <span class="text-danger"></span>
                <input type="text" name="email" class="form-control" placeholder="Email"/>
              </div>
              <div>
                <span class="text-danger"></span>
                <input type="file" name="profile_pic" class="form-control"/><br>
              </div>
              <div>
                <button class="btn btn-default" type="submit">Update</button>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <div class="clearfix"></div>
                <br />

                <div>
                  <h1><i class="fa fa-hand-pointer-o"></i> ClickableBrand, Inc.</h1>
                  <p>©2016 All Rights Reserved. Gentelella Alela! is a Bootstrap 3 template. Privacy and Terms</p>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?=base_url('assets/jquery.js')?>"></script>
    <!-- Bootstrap -->
    <script src="<?=base_url('assets/vendors/bootstrap/js/bootstrap.min.js')?>"></script>

    <script src="<?=base_url('assets/build/js/user.js')?>"></script>
  </body>
</html>
