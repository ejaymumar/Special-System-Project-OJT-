<div class="ui fixed inverted menu">
<div class="ui container" style="min-height: 50px;padding: 10px">
  <a href="#" class="header item">
    Inventory System
  </a>
</div>
</div>