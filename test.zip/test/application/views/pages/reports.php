
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3><?=$page?> Page</h3>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Select Items To Compare</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <form>
                      <div class="form-group">
                        <div class="col-md-8">
                          <label class="form-label">Select Item: </label>
                          <select name="item" class="form-control">
                            <option hidden value="0">--Select Item--</option>
                          </select>
                        </div>
                        
                        <div id="item-details" class="col-md-2">
                          <!-- <span><i class="fa fa-plug"></i> Total Users</span>
                          <div>2500</div> -->
                          <!-- <span><i class="green">4% </i> From last Week</span> -->
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

