                <!-- footer content -->
                <footer>
                    <div class="pull-right">
                        STS <a href="https://colorlib.com">Colorlib</a>
                    </div>
                    <div class="clearfix"></div>
                </footer>
                <!-- /footer content -->
            </div>
        </div>

        <!-- jQuery -->
        <script src="<?=base_url('assets/jquery.js')?>"></script>
        <!-- Bootstrap -->
        <script src="<?=base_url('assets/vendors/bootstrap/js/bootstrap.min.js')?>"></script>
        <!-- NProgress -->
        <!-- <script src="../vendors/nprogress/nprogress.js"></script> -->

        <!-- Custom Theme Scripts -->
        <script src="<?=base_url('assets/build/js/custom.min.js')?>"></script>

        <!-- DataTables -->
        <script src="<?=base_url('assets/vendors/datatables/js/jquery.dataTables.min.js')?>"></script>
        <script src="<?=base_url('assets/vendors/datatables/js/dataTables.bootstrap.min.js')?>"></script>

        <!-- Programmers eSpeciality -->
        <script src="<?=base_url('assets/functionalities.js')?>"></script>

        <!-- simple UI operations -->
        <script>

                $(document).ready(function(){
                    $('[name=row]').on('change',function(){
                        //alert($(this).val());
                        if($(this).val() != 0){
                            $('[name=hostname]').attr('disabled', false);
                            $('[name=hostname]').val('R'+$(this).val() + 'S');
                        }

                        //alert($('#frmComputer').serialize());
                    })
                })
        </script>
        
    </body>
</html>
