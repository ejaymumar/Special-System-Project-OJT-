                <!-- footer content -->
                <footer>
                    <div class="pull-right">
                        STS <a href="https://colorlib.com">Colorlib</a>
                    </div>
                    <div class="clearfix"></div>
                </footer>
                <!-- /footer content -->
            </div>
        </div>

        <!-- jQuery -->
        <script src="<?=base_url('assets/jquery.js')?>"></script>
        <!-- Bootstrap -->
        <script src="<?=base_url('assets/vendors/bootstrap/js/bootstrap.min.js')?>"></script>
        <!-- NProgress -->
        <!-- <script src="../vendors/nprogress/nprogress.js"></script> -->

        <!-- Custom Theme Scripts -->
        <script src="<?=base_url('assets/build/js/custom.min.js')?>"></script>

        <!-- DataTables -->
        <script src="<?=base_url('assets/vendors/datatables/js/jquery.dataTables.min.js')?>"></script>
        <script src="<?=base_url('assets/vendors/datatables/js/dataTables.bootstrap.min.js')?>"></script>
        <script src="<?=base_url('assets/vendors/datatables/js/responsive.bootstrap.js')?>"></script>

        <!-- Programmers eSpeciality -->
        <script src="<?=base_url('assets/functionalities.js')?>"></script>
        
    </body>
</html>
