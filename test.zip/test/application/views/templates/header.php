<!DOCTYPE html>
<html lang="en">
    <head>

        <title><?=$title?> | Session name</title>

        <!-- Bootstrap -->
        <link href="<?=base_url('assets/vendors/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="<?=base_url('assets/vendors/font-awesome/font-awesome.min.css')?>" rel="stylesheet">
        <!-- NProgress -->
        <!-- <link href="../vendors/nprogress/nprogress.css" rel="stylesheet"> -->

        <!-- Custom Theme Style -->
        <link href="<?=base_url('assets/build/css/custom.min.css')?>" rel="stylesheet">

        <!-- DataTables -->
        <link rel="stylesheet" href="<?=base_url('assets/vendors/datatables/css/dataTables.bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?=base_url('assets/vendors/datatables/css/responsive.bootstrap.min.css')?>">

        <link rel="shortcut icon" href="<?=base_url('assets/build/images/logo.png')?>" type="image/gif"/>

        <style>
            td.details-control {
                background: url("<?=base_url('assets/build/images/details_open.png')?>") no-repeat center center;
                cursor: pointer;
            }
            tr.shown td.details-control {
                background: url("<?=base_url('assets/build/images/details_close.png')?>") no-repeat center center;
            }


            .modal-header {
                padding:9px 15px;
                border-bottom:1px solid #eee;
                background-color: #3f5367;
                -webkit-border-top-left-radius: 5px;
                -webkit-border-top-right-radius: 5px;
                -moz-border-radius-topleft: 5px;
                -moz-border-radius-topright: 5px;
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
            }

            .group-line{
                border: thin #3f5367 solid;
                padding:20px;
                border-radius:5px;
            }
        </style>
        <script>
            var base_url = function(loc){
                    var url = "<?php echo site_url('" + loc + "'); ?>";
                    return url;
                }
            
        </script>
    </head>
   
    <body class="nav-md">
        <div class="container body">
            <div class="main_container">