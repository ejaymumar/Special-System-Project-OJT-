<!DOCTYPE html>
<html lang="en">
    <head>

        <title><?=$title?> | Session name</title>

        <!-- Bootstrap -->
        <link href="<?=base_url('assets/vendors/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="<?=base_url('assets/vendors/font-awesome/font-awesome.min.css')?>" rel="stylesheet">
        <!-- NProgress -->
        <!-- <link href="../vendors/nprogress/nprogress.css" rel="stylesheet"> -->

        <!-- Custom Theme Style -->
        <link href="<?=base_url('assets/build/css/custom.min.css')?>" rel="stylesheet">

        <!-- DataTables -->
        <link rel="stylesheet" href="<?=base_url('assets/vendors/datatables/css/dataTables.bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?=base_url('assets/vendors/datatables/css/responsive.bootstrap.min.css')?>">

        <link rel="shortcut icon" href="<?=base_url('assets/build/images/logo.png')?>" type="image/gif"/>

        <style>
            td.details-control {
                background: url("<?=base_url('assets/build/images/details_open.png')?>") no-repeat center center;
                cursor: pointer;
            }
            tr.shown td.details-control {
                background: url("<?=base_url('assets/build/images/details_close.png')?>") no-repeat center center;
            }
        </style>

    </head>
   
    <body class="nav-md">
        <div class="container body">
            <div class="main_container">