
var save_method;
var table;

/* Formatting function for row details - modify as you need */
{/* <th></th>
                      <th>ID </th>
                      <th>Type </th>
                      <th>Row </th>
                      <th>Hostname </th>
                      <th>Serial </th>
                      <th>Motherboard </th>
                      <th>Processor </th>
                      <th>RAM </th>
                      <th>HDD </th>
                      <th>VDCard </th>
                      <th>Space </th>
                      <th>Remarks </th>
                      <th>Date Added </th>
                      <th>Action </th> */}

$(document).ready(function(){
    // store the dataTable initialization so that it can be used sa mga functions later on
    table = $('#tbl_computers').DataTable( {
        "ajax": "http://localhost:88/test/assets/viewComputer",
        "columns": [
            {
                "className": 'details-control',
                "orderable": false
            },
            {"visible": false},
            {"visible": false},
            {"visible": false},
            null,
            {"visible": false},
            null,
            null,
            null,
            null,
            null,
            null,
            {"visible": false},
            {"visible": false},
            {"orderable": false}
          ]
    } );

    $('#tbl_computers tbody').on('click', 'td.details-control', function () {
        //TEST
        //alert('ds');
        var tr = $(this).closest('tr');
        var row = table.row( tr );

        if ( row.child.isShown() ) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        }
        else {
            // Open this row
            
            row.child( format(row.data()) ).show();
            tr.addClass('shown');
        }
    });

    $('#frmComputer').on('submit',function(e){
        e.preventDefault();
        alert($(this).serialize());
        save();
        table.ajax.reload();
    });

    $('#btnComp').on('click',function(){

        save_method = "add";
        $('#modalComputer').modal('show');
        $('.modal-title').html('Computers Adding');
        $('#frmComputer')[0].reset();
    })
})

function format( d ) {
    // `d` is the original data object for the row
    return '<table class="table table-bordered">'+
        '<tr>'+
            '<td>Serial:</td>'+
            '<td>'+d.name+'</td>'+
            '<td>Serial:</td>'+
            '<td>'+d.amore+'</td>'+
        '</tr>'+
        '<tr>'+
            '<td>User:</td>'+
            '<td>'+d.extn+'</td>'+
        '</tr>'+
        '<tr>'+
            '<td>Peripherals:</td>'+
            '<td>' + d.more + '</td>'+
        '</tr>'+
    '</table>';
}


function save() {
    $('#btnSubmit').text('saving...');
    $('#btnSubmit').attr('disabled',true);
    var url;

    if(save_method == 'add') {
        url = "http://localhost:88/test/assets/addAsset";
    } else {
        url = "<?php echo base_url('assets/updateAsset')?>";
    }

    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#frmComputer').serialize(),
        dataType: "JSON",
        success: function(data)
        {

            // if(data.status) //if success close modal and reload ajax table
            // {
            //     $('#modal_form').modal('hide');
            // }
            // else
            // {
            //     for (var i = 0; i < data.inputerror.length; i++) 
            //     {
            //         $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
            //         $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
            //     }
            // }
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 


        },
        error: function()
        {
            // alert('Error adding / update data');
            // $('#btnSave').text('save'); //change button text
            // $('#btnSave').attr('disabled',false); //set button enable 

        }
    });
}