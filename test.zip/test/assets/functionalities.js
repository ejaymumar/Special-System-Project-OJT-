// _____ ____  __  __ _____  _    _ _______ ______ _____              _____ _____ ______ _______   ______ _    _ _   _  _____ _______ _____ ____  _   _  _____ 
// / ____/ __ \|  \/  |  __ \| |  | |__   __|  ____|  __ \      /\    / ____/ ____|  ____|__   __| |  ____| |  | | \ | |/ ____|__   __|_   _/ __ \| \ | |/ ____|
// | |   | |  | | \  / | |__) | |  | |  | |  | |__  | |__) |    /  \  | (___| (___ | |__     | |    | |__  | |  | |  \| | |       | |    | || |  | |  \| | (___  
// | |   | |  | | |\/| |  ___/| |  | |  | |  |  __| |  _  /    / /\ \  \___ \\___ \|  __|    | |    |  __| | |  | | . ` | |       | |    | || |  | | . ` |\___ \ 
// | |___| |__| | |  | | |    | |__| |  | |  | |____| | \ \   / ____ \ ____) |___) | |____   | |    | |    | |__| | |\  | |____   | |   _| || |__| | |\  |____) |
// \_____\____/|_|  |_|_|     \____/   |_|  |______|_|  \_\ /_/    \_\_____/_____/|______|  |_|    |_|     \____/|_| \_|\_____|  |_|  |_____\____/|_| \_|_____/ 
var method;

/* Formatting function for row details - modify as you need ? */

$(document).ready(function(){
    // store the dataTable initialization so that it can be used sa mga functions later on "http://localhost:88/test/assets/viewComputer"
    var table = $('#tbl_computers').DataTable( {
        "ajax": base_url('assets/viewComputer'),
        "columns": [
            {
                "className": 'details-control',
                "orderable": false
            },
            {"visible": false},
            {"visible": false},
            {"visible": false},
            null,
            {"visible": false},
            null,
            null,
            null,
            null,
            null,
            null,
            {"visible": false},
            {"visible": false},
            {"orderable": false}
          ]
    } );

    $('#tbl_computers tbody').on('click', 'td.details-control', function () {
        //TEST
        //alert('ds');
        var tr = $(this).closest('tr');
        var row = table.row( tr );
        
        //alert(row.data());

        if ( row.child.isShown() ) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        }
        else {
            // Open this row
            
            row.child( format(row.data()) ).show();
            // console.log(row.data());
            console.log(row.data());
            tr.addClass('shown');
        }
    });

    $('[name=row]').on('change',function(){
        //alert($(this).val());
        if($(this).val() != 0){
            $('[name=hostname]').attr('disabled', false);
            $('[name=hostname]').val('R'+$(this).val() + 'S');
        }

        //alert($('#frmComputer').serialize());
    })

    $('#frmComputer').on('submit',function(e){
        //e.preventDefault();
        SubmitComputer();
        
    });

    $('#btnComp').on('click',function(){

        method = "add";
        $('#modalComputer').modal('show');
        $('.modal-title').html('Computers');
        $('#frmComputer')[0].reset();
    })

    $('#tbl_computers tbody').on('click', 'td button.btnUpdate',function(){
        var tr = $(this).closest('tr');
        var row = table.row(tr);
        var id = row.data()[1];

        method = "update";
        $('#modalComputer').modal('show');
        $('.modal-title').html('Update');
        $('#btnSubmit').text('Update');
        $('[name=hostname]').attr('disabled', false);

        $.ajax({
            url : base_url('assets/getSpecific/') + id,
            type : "GET",
            dataType: "JSON",
            success : function(data){
                if(data){
                    //console.log(data[0]['motherboard']);
                    $.each(data[0],function(key, val){
                        //alert(key + " " + val);
                        $('[name=' + key +']').val(val);
                    })
                }
            }
        })
        
    })

    $('#tbl_computers tbody').on('click', 'td button.btnDelete',function(){
        var tr = $(this).closest('tr');
        var row = table.row(tr);
        var id = row.data()[1];
        // CHANGE LANG NYA ANG DESIGN SA PROMPT
        if(confirm("Do you want to delete this ?")){
            $.ajax({
                url : base_url('assets/deleteAsset/') + id,
                type : "POST",
                dataType: "JSON",
                success: function(data){
                    if(data.status){
                        //change for future
                        alert('deleted');
                        table.ajax.reload();
                    }else{
                        alert('not delete');
                    }
                } 
            })
        }
    })
    function SubmitComputer() {
        $('#btnSubmit').text('saving...');
        $('#btnSubmit').attr('disabled',true);
        var url;
    
        if(method == 'add') {
            url = base_url('assets/addAsset');
           
        } else {
            url = base_url('assets/updateAsset');
        }

        // ajax adding data to database
         $.ajax({
            url : url,
            type: "POST",
            data: $('#frmComputer').serialize(),
            dataType: "JSON",
            success: function(data)
            {
                console.log(data);
                if(data.status) //if success close modal and reload ajax table
                {
                    $('#modalComputer').modal('hide');
                    table.ajax.reload();
                    //alert('ok');
                }
                // ADD FORM VALIDATIONS
                // else
                // {
                    
                // }
                $('#btnSubmit').text('Submit'); //change button text
                $('#btnSubmit').attr('disabled',false); //set button enable 
            }
        });
    
    
    }
    function format( d ) {
        // `d` is the original data object for the row
        var de = new Date();
        var n = de.getMonth();
        //d[13].substr(0,10)
        return '<table class="table table-bordered">'+
            '<tr>'+
                '<td>Type:</td>'+
                '<td>'+d[2]+'</td>'+
                '<td>Serial:</td>'+
                '<td>'+d[5]+'</td>'+
            '</tr>'+
            '<tr>'+
                '<td>Row:</td>'+
                '<td>'+d[3]+'</td>'+
                '<td>Remarks:</td>'+
                '<td>'+d[12]+'</td>'+
            '</tr>'+
            '<tr>'+
                '<td>Date Added:</td>'+
                '<td>' + moment(d[13].substr(0,10)).format('MMMM D, YYYY') + '</td>'+
            '</tr>'+
        '</table>';
    }
    
    
})



