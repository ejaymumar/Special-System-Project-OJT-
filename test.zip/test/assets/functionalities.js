/* Formatting function for row details - modify as you need */
function format( d ) {
    // `d` is the original data object for the row
    return '<table class="table table-bordered">'+
        '<tr>'+
            '<td>Serial:</td>'+
            '<td>'+d.name+'</td>'+
            '<td>Serial:</td>'+
            '<td>'+d.amore+'</td>'+
        '</tr>'+
        '<tr>'+
            '<td>User:</td>'+
            '<td>'+d.extn+'</td>'+
        '</tr>'+
        '<tr>'+
            '<td>Peripherals:</td>'+
            '<td>' + d.more + '</td>'+
        '</tr>'+
    '</table>';
}

$(document).ready(function(){
    // store the dataTable initialization so that it can be used sa mga functions later on
    var table = $('#tbl_computers').DataTable( {
        "responsive": true,
        "columns": [
            {
                "className":      'details-control',
                "orderable":      false,
                "data":           null,
                "defaultContent": ''
            },
            { "data": "Invoice" },
            { "data": "Invoice Date" },
            { "data": "Order" },
            { "data": "Bill to Name" },
            { "data": "Amount" },
            { 
                "orderable": false,
                "data": "Action" }
        ],
        "order": [[1, 'asc']]
    } );

    $('#tbl_computers tbody').on('click', 'td.details-control', function () {
        //TEST
        //alert('ds');
        var tr = $(this).closest('tr');
        var row = table.row( tr );

        if ( row.child.isShown() ) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        }
        else {
            // Open this row
            
            row.child( format(row.data()) ).show();
            tr.addClass('shown');
        }
    });

    $('#frmComputer').on('submit',function(e){
        e.preventDefault();
        alert($(this).serialize());
    })
})