-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2017 at 03:26 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory-system`
--

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `id` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `manufacturer` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `remarks` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `computer`
--

CREATE TABLE `computer` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `row` varchar(50) NOT NULL,
  `hostname` varchar(50) NOT NULL,
  `serial` varchar(100) NOT NULL,
  `motherboard` varchar(100) NOT NULL,
  `processor` varchar(100) NOT NULL,
  `RAM` decimal(18,2) NOT NULL,
  `HDD` double NOT NULL,
  `VDCard` varchar(100) NOT NULL,
  `space` varchar(100) NOT NULL,
  `remarks` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `application_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `computer`
--

INSERT INTO `computer` (`id`, `type`, `row`, `hostname`, `serial`, `motherboard`, `processor`, `RAM`, `HDD`, `VDCard`, `space`, `remarks`, `date_added`, `application_id`) VALUES
(1, 'Laptop', '10', 'R10S34', '343434', 'Asus', '203', '2312.00', 230, '232', 'Old Operation', 'sdsadad', '2017-11-16 08:51:04', NULL),
(2, 'Laptop', '3', 'R3S23', '232323', '23', '3232', '3.00', 23, '23', 'Old Operation', 'sdsd', '2017-11-16 08:51:31', NULL),
(3, 'Laptop', '5', 'R5S23', 'ds', 'asdkjh', 'jkhkj', '0.00', 0, 'kjhjk', 'Old Operation', 'jkhjkasd', '2017-11-16 09:18:41', NULL),
(4, 'Computer', '5', 'R5S23', '23232', 'sdad', 'asd', '0.00', 0, 'dasd', 'Old Operation', 'asd', '2017-11-16 09:46:19', NULL),
(5, 'Computer', '9', 'R9S', '2323', 'asd', '111', '1112222222.00', 22, '2222', 'Expansion', 'asdas', '2017-11-28 09:54:15', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `computers_peripherals`
--

CREATE TABLE `computers_peripherals` (
  `computerID` int(11) NOT NULL,
  `peripheralID` int(11) NOT NULL,
  `computer_id` int(11) DEFAULT NULL,
  `peripheral_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `space` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `id` int(11) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` text NOT NULL,
  `tag` varchar(100) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `peripheral`
--

CREATE TABLE `peripheral` (
  `id` int(11) NOT NULL,
  `asset_name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `availability` varchar(50) NOT NULL,
  `space` varchar(50) NOT NULL,
  `remarks` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `peripheralInfo_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `peripheral`
--

INSERT INTO `peripheral` (`id`, `asset_name`, `status`, `availability`, `space`, `remarks`, `date_added`, `peripheralInfo_id`) VALUES
(1, 'Mouse', 1, 'ok', 'kk', 'kkkkk', '2017-11-28 09:10:02', NULL),
(2, 'Mouse', 1, 'kKKK', 'kkskd', 'sadasd', '2017-11-28 09:10:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `peripheral_info`
--

CREATE TABLE `peripheral_info` (
  `id` int(11) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `serial` varchar(50) NOT NULL,
  `port_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `usertype` varchar(50) NOT NULL DEFAULT 'Admin',
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userinfo_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `status`, `usertype`, `date_added`, `userinfo_id`) VALUES
(9, 'cherry', 'ann', 1, 'Admin', '2017-11-30 01:53:43', 42),
(14, 'ejaymumar', '123', 0, 'Admin', '2017-12-01 02:26:05', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) NOT NULL,
  `DOB` date NOT NULL,
  `age` int(11) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `image` varchar(100) DEFAULT 'logo.png',
  `first_access` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `firstname`, `middlename`, `lastname`, `DOB`, `age`, `contact`, `email`, `image`, `first_access`) VALUES
(42, 'Cherry', 'Ann', 'Molins', '1997-11-10', 20, '095040', 'sad@mail.com', 'Jellyfish.jpg', '2017-11-30 21:15:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `computer`
--
ALTER TABLE `computer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_applicationID` (`application_id`);

--
-- Indexes for table `computers_peripherals`
--
ALTER TABLE `computers_peripherals`
  ADD PRIMARY KEY (`computerID`,`peripheralID`),
  ADD KEY `fk_computerID` (`computer_id`),
  ADD KEY `fk_peripheralID` (`peripheral_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_userID` (`user_id`);

--
-- Indexes for table `peripheral`
--
ALTER TABLE `peripheral`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_peripheralInfoID` (`peripheralInfo_id`);

--
-- Indexes for table `peripheral_info`
--
ALTER TABLE `peripheral_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_userinfoID` (`userinfo_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `computer`
--
ALTER TABLE `computer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `peripheral`
--
ALTER TABLE `peripheral`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `peripheral_info`
--
ALTER TABLE `peripheral_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `computer`
--
ALTER TABLE `computer`
  ADD CONSTRAINT `fk_applicationID` FOREIGN KEY (`application_id`) REFERENCES `application` (`id`);

--
-- Constraints for table `computers_peripherals`
--
ALTER TABLE `computers_peripherals`
  ADD CONSTRAINT `fk_computerID` FOREIGN KEY (`computer_id`) REFERENCES `computer` (`id`),
  ADD CONSTRAINT `fk_peripheralID` FOREIGN KEY (`peripheral_id`) REFERENCES `peripheral` (`id`);

--
-- Constraints for table `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `fk_userID` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Constraints for table `peripheral`
--
ALTER TABLE `peripheral`
  ADD CONSTRAINT `fk_peripheralInfoID` FOREIGN KEY (`peripheralInfo_id`) REFERENCES `peripheral_info` (`id`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_userinfoID` FOREIGN KEY (`userinfo_id`) REFERENCES `user_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
